package assessment;

import java.util.Scanner;

public class SubstringAndConcatenation {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the String: ");
		StringBuilder val = new StringBuilder(sc.nextLine());
		
		if(val.length() < 2)
		{
			val.append("@@");
		}
		
		System.out.println("The substring is: "+val.substring(0, 2));
	}
}
